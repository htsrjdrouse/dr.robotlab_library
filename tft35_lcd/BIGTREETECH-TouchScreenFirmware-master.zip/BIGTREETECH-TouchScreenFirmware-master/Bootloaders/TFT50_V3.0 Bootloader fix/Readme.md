## Bootloader for TFT display 50 V3.0

*Flash program to download here:
*https://uloz.to/file/N8qY2gSUhn3t/en-stm32cubeprog-v2-3-0-zip

